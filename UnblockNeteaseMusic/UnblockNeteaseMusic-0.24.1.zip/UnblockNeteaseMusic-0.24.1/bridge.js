#!/usr/bin/env node
require('./src/bridge')